//
//  MQRequestChannel.hpp
//  313PA6
//



#include "reqchannel.h"
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <cstring>
#include <iostream>
#include <fstream>
#include <fcntl.h>
#include <unistd.h>

class MQRequestChannel : public RequestChannel {
private:
  std::string   my_name = "";
  std::string side_name = "";
  Side     my_side;
  
  key_t key;
  int msgid;



public:
  MQRequestChannel(const string _name, const Side _side);
  ~MQRequestChannel();
  string cread();
  int cwrite(string _msg);


};
