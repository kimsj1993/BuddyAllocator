//
//  MQRequestChannel.cpp
//  313PA6
//


#include "MQRequestChannel.h"

const int MAX_MESSAGE = 255;

struct My_msgbuf{
  long mtype;
  char mtext[255];
};


MQRequestChannel::MQRequestChannel(const std::string _name, const Side _side) :
my_name(_name), my_side(_side), side_name((_side == RequestChannel::SERVER_SIDE) ? "SERVER" : "CLIENT")
{
  
  string file_name = "mq_" + _name;
  int fd1 = open(file_name.c_str(), O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR);
  close(fd1);
  key = ftok(file_name.c_str(), 1);
  msgid = msgget(key, 0644 | IPC_CREAT); //msqid is class member variable.
  
  if( msgid < 0 ){
    EXITONERROR(my_name + " : " + "msgget fail");
  }
  
}

MQRequestChannel::~MQRequestChannel() {
  msgctl(msgid, IPC_RMID, NULL);
  string file_name  = "mq_" + my_name;
  remove(file_name.c_str());
  
}



string MQRequestChannel::cread() {

  
  
  My_msgbuf buf;
  if (my_side == SERVER_SIDE) {
    if (msgrcv(msgid, &buf, sizeof(buf.mtext), 2, 0) <= 0 ) {
     // EXITONERROR( "SERVERSIDE: msgcrvc fail");
    }
  } else {
    if( msgrcv(msgid, &buf, sizeof buf.mtext, 1, 0) <= 0){
      EXITONERROR( "Client: msgcrvc fail");
    }
  }
  
  string msg_received = buf.mtext;
  
  //Return string.
  return msg_received;
  
}

int MQRequestChannel::cwrite(string _msg) {

  My_msgbuf buf;

  //Get Message Length
  size_t length = _msg.length();
  if( length >= MAX_MESSAGE ){
    std::cerr << my_name << " : " << "Message Too Long for Channel" << std::endl;
    return -1;
  }

  strncpy(buf.mtext, _msg.c_str(), length+1);
  
  if (my_side == SERVER_SIDE) {
    buf.mtype = 1;
    if( msgsnd(msgid, &buf, length+1, 0) == -1){
     // EXITONERROR( "SERVERSIDE: msgsnd fail");
      return -1;
    }
    
  } else {
    buf.mtype = 2;
    
    if( msgsnd(msgid, &buf, length+1, 0) == -1){
      EXITONERROR( "Client: msgsnd fail");
      return -1;
    }
  }
  return 0;
  
}
  
