//
//  FIFO_RequestChannel.hpp
//  313PA6
//
//  Created by 김승진 on 11/29/18.
//  Copyright © 2018 SeugnJin Kim. All rights reserved.
//

#ifndef FIFO_RequestChannel_h
#define FIFO_RequestChannel_h

#include <iostream>
#include <fstream>
#include <exception>
#include <string>
#include "reqchannel.h"
#include <stdio.h>


class FIFORequestChannel: public RequestChannel {
  // typedef enum {SERVER_SIDE, CLIENT_SIDE} Side;
  
  // typedef enum {READ_MODE, WRITE_MODE} Mode;
  
private:
  string   my_name = "";
  string side_name = "";
  Side     my_side;
  
  /*  The current implementation uses named pipes. */

  
  int wfd;
  int rfd;
  
  string pipe_name(Mode _mode);
  void create_pipe (string _pipe_name);
  void open_read_pipe(string _pipe_name);
  void open_write_pipe(string _pipe_name);


public:

  FIFORequestChannel(const string _name, const Side _side);

  
  ~FIFORequestChannel();

  
  string cread();

  
  int cwrite(string _msg);

  
  string name();
  
  int read_fd();
  
  int write_fd();
  
};


#endif /* FIFO_RequestChannel_h */
