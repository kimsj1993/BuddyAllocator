//
//  MQ_RequestChannel.hpp
//  313PA6
//
//  Created by 김승진 on 11/29/18.
//  Copyright © 2018 SeugnJin Kim. All rights reserved.
//

#ifndef MQ_RequestChannel_hpp
#define MQ_RequestChannel_hpp

#include "reqchannel.h"
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>


class MQ_RequestChannel : public RequestChannel {
private:
  key_t key;
  int message_id;
  int send_id;
  int reveive_id;
  
  
public:
  MQ_RequestChannel(const string name, const Side side);
  ~MQ_RequestChannel();
  void cwrite(string message);
  int get_send();
  int get_receive();
  
  
};

#endif /* MQ_RequestChannel_hpp */
