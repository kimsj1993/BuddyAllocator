//
//  KernelSemaphore.cpp
//  313PA6
//
//  Created by 김승진 on 11/29/18.
//  Copyright © 2018 SeugnJin Kim. All rights reserved.
//

#include "KernelSemaphore.h"

KernelSemaphore:: KernelSemaphore(int _val, key_t key) {
  sem_id = semget(key, 1, IPC_CREAT | 0666);
  sembuf sb = {0, (short)_val, 0};
  
  if (_val !=0)
  {
    semop(sem_id, &sb, 1);
  }
}

KernelSemaphore:: ~KernelSemaphore() {
  semctl(sem_id, IPC_RMID, 0);
}

//Acquire
void KernelSemaphore::P() {
  sembuf sb = {0, -1 ,0};
  semop(sem_id, &sb, 1);
}

void KernelSemaphore::V() {
  sembuf sb = {0, 1, 0};
  semop(sem_id, &sb, 1);
}






