//
//  KernelSemaphore.hpp
//  313PA6
//
//  Created by 김승진 on 11/29/18.
//  Copyright © 2018 SeugnJin Kim. All rights reserved.
//

#ifndef KernelSemaphore_h
#define KernelSemaphore_h

#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>

class KernelSemaphore {
private:
  int sem_id;
public:
  KernelSemaphore(int _val, key_t key);
  ~KernelSemaphore();
  
  void P(); // Acquire Lock
  void V(); //Release Lock

};


#endif /* KernelSemaphore_h */
